document.querySelectorAll('.lightbox').forEach(item => {
    item.addEventListener('click', event => {
        event.preventDefault();
        const imgSrc = item.getAttribute('href');
        const lightbox = document.createElement('div');
        lightbox.className = 'lightbox-overlay';
        lightbox.innerHTML = `<img src="${imgSrc}" alt="Lightbox Image">
                            <span class="close-btn">&times;</span>`;
        document.body.appendChild(lightbox);

        lightbox.querySelector('.close-btn').addEventListener('click', () => {
            document.body.removeChild(lightbox);
        });
    });
});
